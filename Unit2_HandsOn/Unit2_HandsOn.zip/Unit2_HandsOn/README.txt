Please run the queries in this order:

1. Drop-Create.sql
2. TestData.sql
3. SelectStatements.sql

Then, in Drop-Create.sql, you can un-comment the part where it
drops the tables, which is probably wise if your testing process 
involves running it more than once.